import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore

class AuthViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    private val _authState = MutableLiveData<AuthState>()
    val authState: LiveData<AuthState> = _authState

    init {
        checkAuthStatus()
    }

    fun checkAuthStatus() {
        auth.currentUser?.let { user ->
            fetchUserRole(user)
        } ?: run {
            _authState.value = AuthState.Unauthenticated
        }
    }

    fun login(email: String, password: String) {
        if (email.isEmpty() || password.isEmpty()) {
            _authState.value = AuthState.Error("Email or Password can't be empty")
            return
        }
        _authState.value = AuthState.Loading
        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    auth.currentUser?.let { user ->
                        fetchUserRole(user)
                    }
                } else {
                    _authState.postValue(
                        AuthState.Error(
                            task.exception?.message ?: "Something went wrong"
                        )
                    )
                }
            }
    }

    private fun fetchUserRole(user: FirebaseUser) {
        val userRef = db.collection("users").document(user.uid)
        userRef.get().addOnSuccessListener { document ->
            if (document.exists()) {
                val role = document.getString("role")
                if (role == "admin") {
                    _authState.value = AuthState.AuthenticatedAsAdmin(user) // Navigate to Admin view
                } else {
                    _authState.value = AuthState.Authenticated(user) // Navigate to User view
                }
            } else {
                _authState.value = AuthState.Unauthenticated
            }
        }.addOnFailureListener { e ->
            _authState.value = AuthState.Error("Error fetching user role: ${e.message}")
        }
    }
    fun signup(name: String, email: String, password: String) {
        if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
            _authState.value = AuthState.Error("Name, Email, or Password can't be empty")
            return
        }
        _authState.value = AuthState.Loading
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    auth.currentUser?.let { user ->
                        assignDefaultRole(user, name, email)
                        _authState.postValue(AuthState.Authenticated(user))
                    }
                } else {
                    _authState.postValue(
                        AuthState.Error(
                            task.exception?.message ?: "Something went wrong"
                        )
                    )
                }
            }
    }

    // Assign user details (name, email, role) in Firestore
    private fun assignDefaultRole(user: FirebaseUser, name: String, email: String) {
        val userRef = db.collection("users").document(user.uid)
        val userData = hashMapOf(
            "name" to name,
            "email" to email,
            "role" to "user"
        )

        // Save the user data to Firestore
        userRef.set(userData)
            .addOnSuccessListener {
                Log.d("AuthViewModel", "User details saved successfully in Firestore")
            }
            .addOnFailureListener { exception ->
                Log.e("AuthViewModel", "Error saving user details: $exception")
            }
    }
    fun signout() {
        auth.signOut()
        _authState.value = AuthState.Unauthenticated
    }
}

sealed class AuthState {
    data class Authenticated(val user: FirebaseUser) : AuthState()
    data class AuthenticatedAsAdmin(val user: FirebaseUser) : AuthState()
    object Unauthenticated : AuthState()
    object Loading : AuthState()
    data class Error(val message: String) : AuthState()
}

