package com.example.humtidumti

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel

class CartViewModel : ViewModel() {
    private val _cartItems = mutableStateOf<MutableList<CartItem>>(mutableListOf())
    val cartItems: List<CartItem> get() = _cartItems.value

    private val _totalPrice = mutableStateOf(0)
    val totalPrice: Int get() = _totalPrice.value
    fun addItemToCart(cartItem: CartItem) {
        val index = _cartItems.value.indexOfFirst { it.id == cartItem.id }
        if (index != -1) {
            val existingItem = _cartItems.value[index]
            val updatedItem = existingItem.copy(count = existingItem.count + 1)
            _cartItems.value = _cartItems.value.toMutableList().apply { set(index, updatedItem) }
        } else {
            _cartItems.value = _cartItems.value.toMutableList().apply { add(cartItem.copy(count = 1)) }
        }
        calculateTotalPrice()
    }
    fun increaseItemCount(cartItem: CartItem) {
        val index = _cartItems.value.indexOfFirst { it == cartItem }
        if (index != -1) {
            val updatedItem = _cartItems.value[index].copy(count = cartItem.count + 1)
            _cartItems.value = _cartItems.value.toMutableList().apply { set(index, updatedItem) }
            calculateTotalPrice()
        }
    }


    fun decreaseItemCount(cartItem: CartItem) {
        val index = _cartItems.value.indexOfFirst { it == cartItem }
        if (index != -1) {
            if (cartItem.count > 1) {
                val updatedItem = _cartItems.value[index].copy(count = cartItem.count - 1)
                _cartItems.value = _cartItems.value.toMutableList().apply { set(index, updatedItem) }
            } else {
                _cartItems.value = _cartItems.value.toMutableList().apply { removeAt(index) }
            }
            calculateTotalPrice()
        }
    }
    private fun updateItemCount(cartItem: CartItem, newCount: Int) {
        _cartItems.value = _cartItems.value.toMutableList().apply {
            val index = indexOfFirst { it.id == cartItem.id }
            if (index != -1) {
                this[index] = cartItem.copy(count = newCount)
            }
        }
        calculateTotalPrice()
    }
    private fun calculateTotalPrice() {
        _totalPrice.value = _cartItems.value.sumOf { it.price * it.count }
    }
    fun removeItemFromCart(cartItem: CartItem) {
        _cartItems.value = _cartItems.value.toMutableList().apply { remove(cartItem) }
        calculateTotalPrice()
    }
    val isCartEmpty: Boolean get() = _cartItems.value.isEmpty()

}


