package com.example.humtidumti.Screen

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import com.example.humtidumti.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.ui.theme.home_back_1
import com.example.humtidumti.ui.theme.home_back_2
import com.example.humtidumti.ui.theme.home_back_3

@Composable
fun Login(modifier: Modifier = Modifier, navController: NavController, authViewModel: AuthViewModel) {
    val authState = authViewModel.authState.observeAsState()
    val context = LocalContext.current
    LaunchedEffect(authState.value) {
        when (val state = authState.value) {
            is AuthState.Authenticated -> {
                navController.navigate("Dashboard") {
                    popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    launchSingleTop = true
                }
            }
            is AuthState.AuthenticatedAsAdmin -> {
                navController.navigate("AdminDashboard") {
                    popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    launchSingleTop = true
                }
            }
            is AuthState.Error -> {
                Toast.makeText(context, state.message, Toast.LENGTH_SHORT).show()
            }
            else -> Unit
        }
    }

    val isAuthenticated = authState.value is AuthState.Authenticated || authState.value is AuthState.AuthenticatedAsAdmin
    BackHandler(enabled = isAuthenticated) {
        (context as? Activity)?.finish()
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(home_back_3, home_back_2, home_back_1),
                    startY = 0f,
                    endY = Float.POSITIVE_INFINITY
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            Image(
                painter = painterResource(id = R.drawable.food),
                contentDescription = "Food PNG",
                modifier = Modifier.size(250.dp).padding(top = 35.dp)
            )

            Text(
                text = "Welcome",
                fontSize = 15.sp,
                color = Color.White,
            )

            Text(
                text = "Login",
                fontSize = 50.sp,
                fontFamily = FontFamily.Cursive,
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )

            Spacer(modifier = Modifier.height(15.dp))

            var email by rememberSaveable { mutableStateOf("") }
            OutlinedTextField(
                modifier = Modifier
                    .height(60.dp)
                    .width(320.dp),
                value = email,
                singleLine = true,
                onValueChange = { newText -> email = newText },
                shape = RoundedCornerShape(24.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                placeholder = { Text("Email", fontSize = 17.sp) },
                leadingIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Filled.Email,
                            contentDescription = "Email Icon"
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                )
            )

            Spacer(modifier = Modifier.height(15.dp))

            var password by rememberSaveable { mutableStateOf("") }
            var passvis by remember { mutableStateOf(false) }
            val icon = if (passvis) painterResource(id = R.drawable.show_pass) else painterResource(id = R.drawable.hide_pass)
            OutlinedTextField(
                modifier = Modifier
                    .height(60.dp)
                    .width(320.dp),
                value = password,
                singleLine = true,
                onValueChange = { password = it },
                shape = RoundedCornerShape(24.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                placeholder = { Text("Password", fontSize = 17.sp) },
                leadingIcon = {
                    IconButton(onClick = {}) {
                        Icon(
                            imageVector = Icons.Filled.Lock,
                            contentDescription = "Password Icon",
                        )
                    }
                },
                trailingIcon = {
                    IconButton(onClick = { passvis = !passvis }) {
                        Icon(
                            painter = icon,
                            contentDescription = "Visibility Icon",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                visualTransformation = if (passvis) VisualTransformation.None else PasswordVisualTransformation()
            )

            Spacer(modifier = Modifier.height(25.dp))

            Button(
                modifier = Modifier
                    .height(54.dp)
                    .width(200.dp)
                    .shadow(
                        elevation = 20.dp,
                        shape = RoundedCornerShape(percent = 50)
                    ),
                onClick = {
                    authViewModel.login(email, password) // Trigger login and role check
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xff164863),
                    contentColor = Color.White
                )
            ) {
                Text(
                    fontSize = 16.sp,
                    text = "Login"
                )
            }

            TextButton(
                onClick = { navController.navigate("Forget_Password") {
                    popUpTo("Flash") { inclusive = true }
                    popUpTo("Login") { inclusive = true }
                } }
            ) {
                Text(
                    text = "Forget Password?",
                    fontSize = 17.sp,
                    color = Color.White
                )
            }
            Spacer(modifier = Modifier.height(5.dp))
            Text(
                text = "- - - - - - - - - - - - - - - -  or  - - - - - - - - - - - - - - - -",
                fontSize = 17.sp,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                modifier = Modifier
                    .height(54.dp)
                    .width(200.dp)
                    .shadow(
                        elevation = 20.dp,
                        shape = RoundedCornerShape(percent = 50)
                    ),
                onClick = { navController.navigate("SignUp") {
                    popUpTo("Flash") { inclusive = true }
                }},
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xff164863),
                    contentColor = Color.White
                )
            ) {
                Text(
                    fontSize = 16.sp,
                    text = "Create an Account"
                )
            }
        }
    }
}

