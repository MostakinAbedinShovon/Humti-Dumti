package com.example.humtidumti

import androidx.compose.runtime.Composable
import  androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.humtidumti.Screen.AdminDashboard
import com.example.humtidumti.Screen.AdminItemlist
import com.example.humtidumti.Screen.AdminProfile
import com.example.humtidumti.Screen.AdminSetting
import com.example.humtidumti.Screen.Admintoprated1
import com.example.humtidumti.Screen.Admintoprated2
import com.example.humtidumti.Screen.Admintoprated3
import com.example.humtidumti.Screen.Admintoprated4
import com.example.humtidumti.Screen.Admintoprated5
import com.example.humtidumti.Screen.Cart
import com.example.humtidumti.Screen.Dashboard
import com.example.humtidumti.Screen.Login
import com.example.humtidumti.Screen.SignUp
import com.example.humtidumti.Screen.Flash
import com.example.humtidumti.Screen.Forget_Password
import com.example.humtidumti.Screen.Itemlist
import com.example.humtidumti.Screen.Profile
import com.example.humtidumti.Screen.Setting
import com.example.humtidumti.Screen.toprated1
import com.example.humtidumti.Screen.toprated2
import com.example.humtidumti.Screen.toprated3
import com.example.humtidumti.Screen.toprated4
import com.example.humtidumti.Screen.toprated5

@Composable
fun MyAppNevigation(modifier: Modifier = Modifier ,authViewModel : AuthViewModel ,cartViewModel: CartViewModel){
    val navController = rememberNavController()

    NavHost(navController = navController , startDestination = "Flash" , builder = {
        composable("Flash"){
            Flash(Modifier ,navController ,authViewModel)
        }
        composable("Login"){
            Login(Modifier ,navController ,authViewModel)
        }
        composable("SignUp"){
            SignUp(Modifier ,navController ,authViewModel)
        }
        composable("Forget_Password"){
            Forget_Password(Modifier ,navController ,authViewModel)
        }
        composable("Dashboard"){
            Dashboard(Modifier ,navController ,authViewModel)
        }
        composable("toprated1"){
            toprated1(Modifier ,navController ,authViewModel ,cartViewModel)
        }
        composable("toprated2"){
            toprated2(Modifier ,navController ,authViewModel,cartViewModel)
        }
        composable("toprated3"){
            toprated3(Modifier ,navController ,authViewModel,cartViewModel)
        }
        composable("toprated4"){
            toprated4(Modifier ,navController ,authViewModel,cartViewModel)
        }
        composable("toprated5"){
            toprated5(Modifier ,navController ,authViewModel,cartViewModel)
        }
        composable("Cart"){
            Cart(Modifier ,navController ,authViewModel, cartViewModel)
        }
        composable("Itemlist"){
            Itemlist(Modifier ,navController ,authViewModel)
        }
        composable("Profile"){
            Profile(Modifier ,navController ,authViewModel)
        }
        composable("Setting"){
            Setting(Modifier ,navController ,authViewModel)
        }
        composable("AdminDashboard"){
            AdminDashboard(Modifier ,navController ,authViewModel)
        }
        composable("Admintoprated1"){
            Admintoprated1(Modifier ,navController ,authViewModel)
        }
        composable("Admintoprated2"){
            Admintoprated2(Modifier ,navController ,authViewModel )
        }
        composable("Admintoprated3"){
            Admintoprated3(Modifier ,navController ,authViewModel )
        }
        composable("Admintoprated4"){
            Admintoprated4(Modifier ,navController ,authViewModel )
        }
        composable("Admintoprated5"){
            Admintoprated5(Modifier ,navController ,authViewModel )
        }
        composable("AdminItemlist"){
            AdminItemlist(Modifier ,navController ,authViewModel)
        }
        composable("AdminSetting"){
            AdminSetting(Modifier ,navController ,authViewModel)
        }
        composable("AdminProfile"){
            AdminProfile(Modifier ,navController ,authViewModel)
        }
    })
}
