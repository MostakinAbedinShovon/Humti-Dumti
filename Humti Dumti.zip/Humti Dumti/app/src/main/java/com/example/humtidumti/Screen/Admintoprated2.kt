package com.example.humtidumti.Screen

import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.humtidumti.R

@Composable
fun Admintoprated2(modifier: Modifier = Modifier, navController: NavController, authViewModel: AuthViewModel){
    val authState by authViewModel.authState.observeAsState()
    val context = LocalContext.current
    var imageUri: Any? by remember { mutableStateOf(R.drawable.salad) }
    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) {
        if (it != null) {
            Log.d("PhotoPicker", "Selected URI: $it")
            imageUri = it
        } else {
            Log.d("PhotoPicker", "No media selected")
        }
    }
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.Unauthenticated -> {
                navController.navigate("Login") {
                    popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    launchSingleTop = true
                }
            }
            else -> Unit
        }
    }
    Box(
        modifier = Modifier
            .height(850.dp)
            .width(360.dp)
    ){
        Column(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
            )
            {
                AsyncImage(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            photoPicker.launch(
                                PickVisualMediaRequest(
                                    ActivityResultContracts.PickVisualMedia.ImageOnly
                                )
                            )
                        },
                    model = ImageRequest.Builder(LocalContext.current)
                        .data(imageUri)
                        .crossfade(enable = true)
                        .build(),
                    contentDescription = "Avatar Image",
                    contentScale = ContentScale.Crop,
                )
                Row(
                    modifier = Modifier
                        .height(100.dp)
                        .width(400.dp)
                        .padding(top = 35.dp , start = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.back),
                        contentDescription = "back",
                        modifier = Modifier
                            .height(63.dp)
                            .width(45.dp)
                            .clickable{
                                navController.navigate("AdminDashboard"){
                                    popUpTo("Admintoprated2") { inclusive = true }
                                }
                            },
                        alignment = Alignment.Center
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                var mytext1 by remember { mutableStateOf("Quinoa Salad Bowl") }
                BasicTextField(
                    modifier = Modifier
                        .height(25.dp)
                        .width(200.dp)
                        .padding(start = 10.dp),
                    value = mytext1,
                    singleLine = true,
                    onValueChange = { newText -> mytext1 = newText },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    textStyle = TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.DarkGray
                    )
                )
                Spacer(modifier = Modifier.padding(start = 90.dp))
                var mytext2 by remember { mutableStateOf("180/-") }
                BasicTextField(
                    modifier = Modifier
                        .height(25.dp)
                        .width(200.dp)
                        .padding(start = 15.dp),
                    value = mytext2,
                    onValueChange = { newText -> mytext2 = newText },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    textStyle = TextStyle(
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFE30B5C)
                    ),
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp , start = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Box(){
                    Image(
                        painter = painterResource(R.drawable.star),
                        contentDescription = "love",
                        modifier = Modifier
                            .height(15.dp)
                            .width(15.dp)
                    )
                    Box(
                    ){
                        Image(
                            painter = painterResource(R.drawable.half),
                            contentDescription = "love",
                            modifier = Modifier
                                .width(15.dp)
                                .height(15.dp)
                                .padding(start = 7.5.dp , top = 1.dp)
                        )
                    }
                }
                Text(
                    text = "4.6 Rating",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color.Gray,
                    modifier = Modifier
                        .padding(start = 10.dp)
                )
                Spacer(modifier = Modifier.padding(start = 90.dp))
                var mytext4 by remember { mutableStateOf("20-25 min") }
                BasicTextField(
                    modifier = Modifier
                        .height(20.dp)
                        .width(70.dp),
                    value = mytext4,
                    singleLine = true,
                    onValueChange = { newText -> mytext4 = newText },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    textStyle = TextStyle(
                        fontWeight = FontWeight.Normal,
                        fontSize = 15.sp
                    ),
                )
                Image(
                    painter = painterResource(R.drawable.time),
                    contentDescription = null,
                    modifier = Modifier
                        .size(15.dp)
                )
            }
            Spacer(modifier = Modifier.padding(top = 10.dp , start = 10.dp))
            Text(
                text = "Ingredients",
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp,
                color = Color.DarkGray,
                modifier = Modifier
                    .padding(start = 10.dp)
            )
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                item(){
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.tomato),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(start = 12.dp ,top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Tomato",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(start = 12.dp ,top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.onion),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Onion",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.chili),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Chili",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.cucumber),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Cucumber",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.lettuce),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Lettuce",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.salt),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 12.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Salt",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 12.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.padding(top = 10.dp , start = 10.dp))
            Text(
                text = "Description",
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp,
                color = Color.DarkGray,
                modifier = Modifier
                    .padding(start = 10.dp)
            )
            Spacer(modifier = Modifier.padding(top = 10.dp , start = 10.dp))
            var mytext1 by remember { mutableStateOf("A quinoa salad bowl is a nutritious and versatile dish that typically features cooked quinoa as its base. Quinoa is a gluten-free grain rich in protein and fiber, making it an excellent choice for both health conscious eaters and those seeking a hearty meal.") }
            BasicTextField(
                modifier = Modifier
                    .height(100.dp)
                    .width(350.dp)
                    .padding(start = 12.dp),
                value = mytext1,
                onValueChange = { newText -> mytext1 = newText },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Done
                ),
                textStyle = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.Gray
                ),
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ){
                Button(
                    modifier = Modifier
                        .padding(start = 12.dp)
                        .height(54.dp)
                        .width(180.dp)
                        .shadow(
                            elevation = 20.dp,
                            shape = RoundedCornerShape(percent = 50)
                        ),
                    onClick = {
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFC21E56),
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        fontSize = 16.sp,
                        text = "Save Changes"
                    )
                }
            }

        }
    }
}