package com.example.humtidumti.Screen

import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.R
import com.exyte.animatednavbar.AnimatedNavigationBar
import com.exyte.animatednavbar.animation.balltrajectory.Straight
import com.exyte.animatednavbar.utils.noRippleClickable

@Composable
fun Itemlist( modifier: Modifier = Modifier,
          navController: NavController,
          authViewModel: AuthViewModel){
    Box(
        modifier = Modifier
            .fillMaxSize(),
    ){
        val navigationBarItems = remember { NavigationBarItems.values() }
        var selectedIndex by remember { mutableStateOf(0) }

        Scaffold(
            modifier = Modifier.padding(bottom = 20.dp),
            bottomBar = {
                AnimatedNavigationBar(
                    modifier = Modifier
                        .height(57.dp)
                        .width(320.dp)
                        .padding(start = 45.dp)
                        .clip(RoundedCornerShape(40.dp)),
                    selectedIndex = 2,
                    ballAnimation = Straight(tween(800)),
                    barColor = Color(0xFFC21E56),
                    ballColor = Color(0xFFC21E56),
                ) {
                    navigationBarItems.forEach { item ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .noRippleClickable {
                                    selectedIndex = item.ordinal
                                    if(item.ordinal == 0) navController.navigate("Dashboard")
                                    else if(item.ordinal == 1) navController.navigate("Cart")
                                    else if(item.ordinal == 2) navController.navigate("Itemlist")
                                    else if(item.ordinal == 3) navController.navigate("Setting")
                                    else if(item.ordinal == 4) navController.navigate("Profile")
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                modifier = Modifier.size(27.dp),
                                imageVector = item.icon,
                                contentDescription = "Bottom Bar Icon",
                                tint = if (selectedIndex != item.ordinal)
                                    Color.White
                                else
                                    Color.LightGray
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    emni()
                }
            }
        }
    }
}

@Preview (showSystemUi = true)
@Composable
fun emni(){
    Box(
        modifier = Modifier
            .fillMaxSize()
    ){
        Box(
            modifier = Modifier.fillMaxSize().background(Color.White)
        ){}
        Card(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 650.dp),
            shape = RoundedCornerShape(bottomEnd = 30.dp, bottomStart = 30.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color(0xFFC21E56)
            )
        ) {
            Text(
                text = "Item",
                fontSize = 30.sp,
                fontWeight = FontWeight.W500,
                color = Color.White,
                modifier = Modifier.padding(start = 150.dp, top = 25.dp),
                fontStyle = FontStyle.Normal
            )
        }
        Spacer(modifier = Modifier.padding(top = 15.dp))
        LazyColumn(
            modifier = Modifier
                .padding(top = 90.dp , start = 10.dp , end = 7.dp)
                .height(620.dp)
        ) {
            item(){
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.dragon_roll),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Dragon Roll",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "120/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 55.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.2",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "15-20 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.threethree),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Grilled Ribeye",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "280/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 40.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.4",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "30-35 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.fourfour),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "BBQ Chicken Pizza",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "160/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 17.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.3",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "20-25 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.oneone),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Mango Tango Slush",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "70/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 17.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.0",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "10-15 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.fivefive),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Chocolate Shake",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "80/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 32.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.1",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "15-17 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.sixsix),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Pepper Chicken",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "240/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 32.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.5",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "20-30 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.svnsvn),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Korean Chicken",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "190/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 32.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.7",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "40-50 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.twotwo),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Green Tea Latte",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 10.dp)
                                )
                                Text(
                                    text = "40/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 35.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.6",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "13-14 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.eigeig),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Pasta Carbonara",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "120/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 30.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.2",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "15-20 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.ninennine),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Smoked BBQ Meat",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "280/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 15.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.4",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "30-35 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.tenten),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Spicy Buff Wings",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "160/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 27.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.3",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "20-25 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.eleele),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Fresh Orange Juice",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "70/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 23.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.0",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "10-15 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(185.dp)
                ){
                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.teltel),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Mint Lemonade",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "80/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 42.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.1",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "15-17 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }

                    Spacer(modifier = Modifier.padding(start = 10.dp))

                    Card(
                        modifier = Modifier
                            .height(170.dp)
                            .width(164.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 4.dp,
                            )
                            .clickable(){
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.thrthr),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(120.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Chicken Teriyaki",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "240/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 30.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "4.5",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(14.dp)
                                )
                                Text(
                                    text = "20-30 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 12.sp,
                                    modifier = Modifier
                                        .padding(start = 28.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(12.dp)
                                )
                            }
                        }

                    }
                }

            }
        }
    }
}