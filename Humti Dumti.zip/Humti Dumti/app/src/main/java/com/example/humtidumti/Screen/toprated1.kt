package com.example.humtidumti.Screen

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.CartItem
import com.example.humtidumti.CartViewModel
import com.example.humtidumti.R

@Composable
fun toprated1(modifier: Modifier = Modifier, navController: NavController, authViewModel: AuthViewModel, cartViewModel: CartViewModel){
    val authState by authViewModel.authState.observeAsState()
    val context = LocalContext.current
    val product = CartItem(
        id = "1",
        title = "Chili Cheese Dog",
        count = 1,
        price = 150,
        image = painterResource(R.drawable.ccd),
        time = "10-15 min"
    )
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.Unauthenticated -> {
                navController.navigate("Login") {
                    popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    launchSingleTop = true
                }
            }
            else -> Unit
        }
    }
    Box(
        modifier = Modifier
            .height(850.dp)
            .width(360.dp)
    ){
        Column(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp)
            )
            {
                Image(
                    painter = painterResource(R.drawable.ccd),
                    contentDescription = "Berger",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                )
                Row(
                    modifier = Modifier
                        .height(100.dp)
                        .width(400.dp)
                        .padding(top = 35.dp , start = 15.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Image(
                        painter = painterResource(R.drawable.back),
                        contentDescription = "back",
                        modifier = Modifier
                            .height(63.dp)
                            .width(45.dp)
                            .clickable(){
                                navController.navigate("Dashboard"){
                                    popUpTo("toprated1") { inclusive = true }
                                }
                            },
                        alignment = Alignment.Center
                    )
                    Spacer(modifier = Modifier.padding(start = 235.dp))
                    Image(
                        painter = painterResource(R.drawable.favorite_white),
                        contentDescription = "love",
                        modifier = Modifier
                            .height(63.dp)
                            .width(55.dp)
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Chili Cheese Dog",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 20.sp,
                    color = Color.DarkGray,
                    modifier = Modifier
                        .padding(start = 10.dp)
                )
                Spacer(modifier = Modifier.padding(start = 90.dp))
                Text(
                    text = "150/-",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 20.sp,
                    color = Color(0xFFE30B5C),
                    modifier = Modifier
                        .padding(start = 43.dp)
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp , start = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Image(
                    painter = painterResource(R.drawable.star),
                    contentDescription = "love",
                    modifier = Modifier
                        .height(15.dp)
                        .width(15.dp)
                )
                Spacer(modifier = Modifier.padding(start = 5.dp))
                Box(){
                    Image(
                        painter = painterResource(R.drawable.star),
                        contentDescription = "love",
                        modifier = Modifier
                            .height(15.dp)
                            .width(15.dp)
                    )
                    Box(
                    ){
                        Image(
                            painter = painterResource(R.drawable.half),
                            contentDescription = "love",
                            modifier = Modifier
                                .width(15.dp)
                                .height(15.dp)
                                .padding(start = 7.5.dp , top = 1.dp)
                        )
                    }
                }
                Text(
                    text = "4.5 Rating",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp,
                    color = Color.Gray,
                    modifier = Modifier
                        .padding(start = 10.dp)
                )
                Text(
                    text = "10-15 min",
                    fontWeight = FontWeight.Normal,
                    fontSize = 15.sp,
                    modifier = Modifier
                        .padding(start = 80.dp)
                )
                Image(
                    painter = painterResource(R.drawable.time),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(start = 3.dp , top = 3.dp)
                        .size(15.dp)
                )
            }
            Spacer(modifier = Modifier.padding(top = 10.dp , start = 10.dp))
            Text(
                text = "Ingredients",
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp,
                color = Color.DarkGray,
                modifier = Modifier
                    .padding(start = 10.dp)
            )
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(70.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                item(){
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.baguete),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(start = 12.dp ,top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Baguete",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(start = 12.dp ,top = 3.dp , end = 20.dp)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.sausage),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Sausage",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.onion),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Onion",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.chili),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Chili",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.cucumber),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Cucumber",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.queijo),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Cheese",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.lettuce),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Lettuce",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 20.dp)
                        )
                    }
                    Column(
                        modifier = Modifier
                            .fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ){
                        Image(
                            painter = painterResource(R.drawable.salt),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 12.dp)
                                .height(40.dp)
                                .width(40.dp),
                        )
                        Text(
                            text = "Salt",
                            fontSize = 10.sp,
                            modifier = Modifier
                                .padding(top = 3.dp , end = 12.dp)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.padding(top = 10.dp , start = 10.dp))
            Text(
                text = "Description",
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp,
                color = Color.DarkGray,
                modifier = Modifier
                    .padding(start = 10.dp)
            )
            Spacer(modifier = Modifier.padding(top = 10.dp , start = 10.dp))
            Text(
                text = "A chili cheese dog is a delicious and hearty variation of the classic hot dog. It typically features a grilled or steamed sausage nestled in a soft bun, topped with a generous helping of chili, often made with ground beef, beans, and a blend of spices.",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                color = Color.Gray,
                modifier = Modifier
                    .padding(start = 10.dp , end = 6.dp)
            )
            Spacer(modifier = Modifier.padding(top = 20.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ){
                Button(
                    modifier = Modifier
                        .padding(start = 12.dp)
                        .height(54.dp)
                        .width(250.dp)
                        .shadow(
                            elevation = 20.dp,
                            shape = RoundedCornerShape(percent = 50)
                        ),
                    onClick = {
                        cartViewModel.addItemToCart(product)
                        Toast.makeText(context, "Added to cart", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFC21E56),
                        contentColor = Color.White
                    )
                ) {
                    Text(
                        fontSize = 16.sp,
                        text = "Add to Cart"
                    )
                }
            }

        }
    }
}
