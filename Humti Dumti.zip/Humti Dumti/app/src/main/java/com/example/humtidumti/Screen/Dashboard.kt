package com.example.humtidumti.Screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.R
import com.exyte.animatednavbar.AnimatedNavigationBar
import com.exyte.animatednavbar.animation.balltrajectory.Straight
import com.exyte.animatednavbar.utils.noRippleClickable

@Composable
fun Dashboard(
    modifier: Modifier = Modifier,
    navController: NavController,
    authViewModel: AuthViewModel
) {
    val authState by authViewModel.authState.observeAsState()
    val context = LocalContext.current
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.Unauthenticated -> {
                navController.navigate("Login") {
                    popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    launchSingleTop = true
                }
            }
            else -> Unit
        }
    }
    //Design part
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Column(

        ) {

            //First part
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                shape = RoundedCornerShape(bottomStart = 25.dp, bottomEnd = 25.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFC21E56)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                ) {
                    Image(
                        painter = painterResource(R.drawable.mypic),
                        contentDescription = "Profile Pic",
                        modifier = Modifier
                            .wrapContentSize()
                            .padding(start = 15.dp, top = 50.dp)
                            .height(50.dp)
                            .width(50.dp)
                            .border(2.dp, Color.White, shape = CircleShape)
                            .shadow(
                                elevation = 30.dp,
                                shape = RoundedCornerShape(percent = 100)
                            )
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop,
                    )
                    Column(
                        modifier = Modifier
                            .width(150.dp)
                            .padding(start = 5.dp, top = 58.dp)
                    ) {
                        Text(
                            text = "Welcome",
                            fontSize = 15.sp,
                            color = Color.White,
                        )
                        Text(
                            text = "Mostakin Abedin",
                            fontSize = 16.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Image(
                        painter = painterResource(R.drawable.bell_white),
                        contentDescription = "Profile Pic",
                        modifier = Modifier
                            .padding(start = 100.dp, top = 60.dp)
                            .height(30.dp)
                            .width(30.dp)
                            .clip(CircleShape)
                            .clickable() {

                            }, //page nevigate korte hbe
                        contentScale = ContentScale.Crop,
                    )

                }

                Spacer(modifier = Modifier.padding(top = 10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 10.dp)
                ) {
                    var value by rememberSaveable { mutableStateOf("") }
                    OutlinedTextField(
                        modifier = Modifier
                            .height(52.dp)
                            .width(280.dp)
                            .shadow(
                                elevation = 20.dp,
                                shape = RoundedCornerShape(percent = 50)
                            ),
                        value = value,
                        singleLine = true,
                        onValueChange = { newText -> value = newText },
                        shape = RoundedCornerShape(24.dp),
                        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        placeholder = {
                            Text(
                                "Search food",
                                fontSize = 17.sp,
                            )
                        },
                        leadingIcon = {
                            IconButton(onClick = {}) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = "Search Icon"
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Search
                        )
                    )
                    Spacer(modifier = Modifier.padding(start = 10.dp))
                    Box(
                        modifier = Modifier
                            .padding(top = 3.dp)
                            .clickable() {},
                        contentAlignment = Alignment.Center
                    ) {
                        Button(
                            onClick = { },
                            modifier = Modifier
                                .height(45.dp)
                                .width(55.dp)
                                .shadow(
                                    elevation = 20.dp,
                                    shape = RoundedCornerShape(percent = 50)
                                ),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                            )

                        ) {}
                        Icon(
                            painter = painterResource(R.drawable.filter),
                            contentDescription = "Filter",
                            modifier = Modifier
                                .size(30.dp)
                        )

                    }
                }
            }


            //Second part
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(145.dp)
            ) {
                item() {
                        Image(
                            painter = painterResource(R.drawable.image1),
                            contentDescription = "Offer 1st image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(start = 10.dp, top = 10.dp)
                                .height(140.dp)
                                .width(335.dp)
                                .shadow(
                                    shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 15.dp , topEnd = 15.dp),
                                    elevation = 5.dp,
                                )
                                .clickable(){},
                        )
                        Image(
                            painter = painterResource(R.drawable.image2),
                            contentDescription = "Offer 1st image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(start = 10.dp, top = 10.dp)
                                .height(140.dp)
                                .width(335.dp)
                                .shadow(
                                    shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 15.dp , topEnd = 15.dp),
                                    elevation = 5.dp,
                                )
                                .clickable(){},
                        )
                        Image(
                            painter = painterResource(R.drawable.image3),
                            contentDescription = "Offer 1st image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(start = 10.dp, top = 10.dp , end = 10.dp)
                                .height(140.dp)
                                .width(335.dp)
                                .shadow(
                                    shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 15.dp , topEnd = 15.dp),
                                    elevation = 5.dp,
                                )
                                .clickable(){},
                        )
                }
            }

            Spacer(modifier = Modifier.padding(top = 10.dp))

            //Third part
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
            ) {
                Text(
                    text = "Catagories",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.DarkGray,
                    modifier = Modifier
                        .padding(start = 17.dp)
                )

                Text(
                    text = "See all",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFC21E56),
                    modifier = Modifier
                        .padding(start = 160.dp , top = 5.dp)
                        .clickable(){} //page nevigate korte hobe
                )
            }

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp),
            ) {
                item(){
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.burger),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(start = 12.dp ,top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp),
                        )
                        Text(
                            text = "Burger",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(start = 17.dp ,top = 65.dp , end = 20.dp)
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.pizza),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "Pizza",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(start = 8.dp ,top = 65.dp , end = 20.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.fried),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "Fried Rice",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(top = 65.dp , end = 20.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.french),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "French Fry",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(top = 65.dp , end = 20.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.chow),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "Chow Mein",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(top = 65.dp , end = 20.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.pastry),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "Pastry",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(start = 8.dp ,top = 65.dp , end = 20.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.hot),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 20.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "Hot Dog",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(top = 65.dp , end = 20.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clickable(){}
                    ){
                        Image(
                            painter = painterResource(R.drawable.donut),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .padding(top = 10.dp , end = 12.dp)
                                .height(50.dp)
                                .width(50.dp)
                        )
                        Text(
                            text = "Donut",
                            fontSize = 12.sp,
                            modifier = Modifier
                                .padding(start = 8.dp ,top = 65.dp , end = 12.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.padding(top = 10.dp))

            //Fourth part
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
            ) {
                Text(
                    text = "Top rated",
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color.DarkGray,
                    modifier = Modifier
                        .padding(start = 17.dp)
                )

                Text(
                    text = "See all",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFFC21E56),
                    modifier = Modifier
                        .padding(start = 175.dp , top = 5.dp)
                        .clickable(){} //page nevigate korte hobe
                )
            }

            Spacer(modifier = Modifier.padding(top = 10.dp))

            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(215.dp)
            ) {
                item(){


                    Card(
                        modifier = Modifier
                            .padding(start = 10.dp )
                            .height(210.dp)
                            .width(220.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 3.dp,
                            )
                            .clickable(){
                                navController.navigate("toprated1")
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.ccd),
                                contentDescription = "one",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(150.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Chili Cheese Dog",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "150/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 17.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 43.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 5.dp)
                            ) {
                                Text(
                                    text = "4.5",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(17.dp)
                                )
                                Text(
                                    text = "10-15 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 60.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(15.dp)
                                )
                            }
                        }

                    }

                    Card(
                        modifier = Modifier
                            .padding(start = 10.dp )
                            .height(210.dp)
                            .width(220.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 3.dp,
                            )
                            .clickable(){
                                navController.navigate("toprated2")
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.salad),
                                contentDescription = "two",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(150.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Quinoa Salad Bowl",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "180/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 17.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 33.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 5.dp)
                            ) {
                                Text(
                                    text = "4.6",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(17.dp)
                                )
                                Text(
                                    text = "20-25 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 60.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(15.dp)
                                )
                            }
                        }

                    }


                    Card(
                        modifier = Modifier
                            .padding(start = 10.dp )
                            .height(210.dp)
                            .width(220.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 3.dp,
                            )
                            .clickable{
                                navController.navigate("toprated3")
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.hawaiian),
                                contentDescription = "three",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(150.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Hawaiian Paradise",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "220/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 17.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 35.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 5.dp)
                            ) {
                                Text(
                                    text = "4.7",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(17.dp)
                                )
                                Text(
                                    text = "30-35 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 60.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(15.dp)
                                )
                            }
                        }

                    }

                    Card(
                        modifier = Modifier
                            .padding(start = 10.dp )
                            .height(210.dp)
                            .width(220.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 3.dp,
                            )
                            .clickable{
                                navController.navigate("toprated4")
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.brgr),
                                contentDescription = "four",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(150.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "BBQ Ranch Delight",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "250/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 17.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 33.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 5.dp)
                            ) {
                                Text(
                                    text = "4.8",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(17.dp)
                                )
                                Text(
                                    text = "40-45 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 60.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(15.dp)
                                )
                            }
                        }

                    }


                    Card(
                        modifier = Modifier
                            .padding(start = 10.dp , end = 10.dp)
                            .height(210.dp)
                            .width(220.dp)
                            .shadow(
                                shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 25.dp , topEnd = 25.dp),
                                elevation = 3.dp,
                            )
                            .clickable{
                                navController.navigate("toprated5")
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ){
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                        ){
                            Image(
                                painter = painterResource(R.drawable.garlic),
                                contentDescription = "five",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .height(150.dp)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(topStart = 25.dp , topEnd = 25.dp))
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 7.dp)
                            ) {
                                Text(
                                    text = "Garlic Chicken",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 16.sp,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                )
                                Text(
                                    text = "300/-",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 17.sp,
                                    color = Color(0xFFE30B5C),
                                    modifier = Modifier
                                        .padding(start = 65.dp)
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 5.dp)
                            ) {
                                Text(
                                    text = "4.9",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 25.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.star),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 5.dp)
                                        .size(17.dp)
                                )
                                Text(
                                    text = "50-60 min",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    modifier = Modifier
                                        .padding(start = 60.dp)
                                )
                                Image(
                                    painter = painterResource(R.drawable.time),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .padding(start = 3.dp , top = 3.dp)
                                        .size(15.dp)
                                )
                            }
                        }

                    }
                }
            }

            //Fifth part
            val navigationBarItems = remember { NavigationBarItems.values() }
            var selectedIndex by remember { mutableStateOf(0) }

            Scaffold(
                modifier = Modifier.padding(bottom = 20.dp),
                bottomBar = {
                    AnimatedNavigationBar(
                        modifier = Modifier
                            .height(57.dp)
                            .width(320.dp)
                            .padding(start = 45.dp)
                            .clip(RoundedCornerShape(40.dp)),
                        selectedIndex = selectedIndex,
                        ballAnimation = Straight(tween(800)),
                        barColor = Color(0xFFC21E56),
                        ballColor = Color(0xFFC21E56),
                    ) {
                        navigationBarItems.forEach { item ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .noRippleClickable {
                                        selectedIndex = item.ordinal
                                        if(item.ordinal == 0) navController.navigate("Dashboard")
                                        else if(item.ordinal == 1) navController.navigate("Cart")
                                        else if(item.ordinal == 2) navController.navigate("Itemlist")
                                        else if(item.ordinal == 3) navController.navigate("Setting")
                                        else if(item.ordinal == 4) navController.navigate("Profile")
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    modifier = Modifier.size(27.dp),
                                    imageVector = item.icon,
                                    contentDescription = "Bottom Bar Icon",
                                    tint = if (selectedIndex != item.ordinal)
                                        Color.White
                                    else
                                        Color.LightGray
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .padding(innerPadding)
                ) {}
            }
        }
    }
}

enum class NavigationBarItems(val icon: ImageVector) {
    Home(icon = Icons.Default.Home),
    Cart(icon = Icons.Default.ShoppingCart),
    Explorer(icon = Icons.Default.AddCircle),
    Setting(icon = Icons.Default.Settings),
    Person(icon = Icons.Default.Person)
}