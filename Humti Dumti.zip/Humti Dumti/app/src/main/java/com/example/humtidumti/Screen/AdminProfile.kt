package com.example.humtidumti.Screen

import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.R
import com.exyte.animatednavbar.AnimatedNavigationBar
import com.exyte.animatednavbar.animation.balltrajectory.Straight
import com.exyte.animatednavbar.utils.noRippleClickable

@Composable
fun AdminProfile( modifier: Modifier = Modifier,
             navController: NavController,
             authViewModel: AuthViewModel){
    val authState by authViewModel.authState.observeAsState()
    val context = LocalContext.current
    LaunchedEffect(authState) {
        when (authState) {
            is AuthState.Unauthenticated -> {
                navController.navigate("Login") {
                    popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    launchSingleTop = true
                }
            }
            else -> Unit
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize(),
    ){
        val navigationBarItems2 = remember { NavigationBarItems2.values() }
        var selectedIndex by remember { mutableStateOf(0) }

        Scaffold(
            modifier = Modifier.padding(bottom = 20.dp),
            bottomBar = {
                AnimatedNavigationBar(
                    modifier = Modifier
                        .height(57.dp)
                        .width(285.dp)
                        .padding(start = 80.dp)
                        .clip(RoundedCornerShape(40.dp)),
                    selectedIndex = 3,
                    ballAnimation = Straight(tween(800)),
                    barColor = Color(0xFFC21E56),
                    ballColor = Color(0xFFC21E56),
                ) {
                    navigationBarItems2.forEach { item ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .noRippleClickable {
                                    selectedIndex = item.ordinal
                                    if(item.ordinal == 0) navController.navigate("AdminDashboard")
                                    else if(item.ordinal == 1) navController.navigate("AdminItemlist")
                                    else if(item.ordinal == 2) navController.navigate("AdminSetting")
                                    else if(item.ordinal == 3) navController.navigate("AdminProfile")
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                modifier = Modifier.size(27.dp),
                                imageVector = item.icon,
                                contentDescription = "Bottom Bar Icon",
                                tint = if (selectedIndex != item.ordinal)
                                    Color.White
                                else
                                    Color.LightGray
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize(),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                    ) {
                        Box(
                            modifier = Modifier.fillMaxSize().background(Color.White)
                        ){}
                        Card(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(bottom = 500.dp),
                            shape = RoundedCornerShape(bottomEnd = 30.dp, bottomStart = 30.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFC21E56)
                            )
                        ) {}
                        Text(
                            text = "Profile",
                            fontSize = 40.sp,
                            fontWeight = FontWeight.W500,
                            color = Color.White,
                            modifier = Modifier.padding(start = 120.dp, top = 50.dp),
                            fontStyle = FontStyle.Normal
                        )
                        Image(
                            painter = painterResource(R.drawable.ppicon),
                            contentDescription = "Profile Pic",
                            modifier = Modifier
                                .padding(start = 120.dp, top = 150.dp)
                                .height(120.dp)
                                .width(120.dp)
                                .border(2.dp, Color.White, shape = CircleShape)
                                .shadow(
                                    elevation = 20.dp,
                                    shape = RoundedCornerShape(percent = 100)
                                )
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop,
                        )
                        Text(
                            text = "Admin",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.W500,
                            color = Color(0xFFC21E56),
                            modifier = Modifier.padding(start = 150.dp, top = 275.dp),
                            fontStyle = FontStyle.Normal
                        )
                        Text(
                            text = "admin@gmail.com",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.W500,
                            color = Color.LightGray,
                            modifier = Modifier.padding(start = 120.dp, top = 300.dp),
                            fontStyle = FontStyle.Normal
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 15.dp, top = 330.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(end = 15.dp)
                                    .clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp))
                                    .clickable{},
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.btn_4),
                                    contentDescription = "button1",
                                    modifier = Modifier
                                        .height(45.dp)
                                        .width(45.dp)
                                )
                                Spacer(modifier = Modifier.padding(start = 20.dp))
                                Text(
                                    text = "Edit Profile",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.W500,
                                    color = Color.DarkGray,
                                    fontStyle = FontStyle.Normal
                                )
                            }
                            Spacer(modifier = Modifier.padding(top = 13.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.btn_1),
                                    contentDescription = "button1",
                                    modifier = Modifier
                                        .height(45.dp)
                                        .width(45.dp)
                                )
                                Spacer(modifier = Modifier.padding(start = 20.dp))
                                Text(
                                    text = "Notification",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.W500,
                                    color = Color.DarkGray,
                                    fontStyle = FontStyle.Normal
                                )
                            }
                            Spacer(modifier = Modifier.padding(top = 13.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.btn_2),
                                    contentDescription = "button1",
                                    modifier = Modifier
                                        .height(45.dp)
                                        .width(45.dp)
                                )
                                Spacer(modifier = Modifier.padding(start = 20.dp))
                                Text(
                                    text = "Calender",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.W500,
                                    color = Color.DarkGray,
                                    fontStyle = FontStyle.Normal
                                )
                            }
                            Spacer(modifier = Modifier.padding(top = 13.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.btn_3),
                                    contentDescription = "button1",
                                    modifier = Modifier
                                        .height(45.dp)
                                        .width(45.dp)
                                )
                                Spacer(modifier = Modifier.padding(start = 20.dp))
                                Text(
                                    text = "Gallery",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.W500,
                                    color = Color.DarkGray,
                                    fontStyle = FontStyle.Normal
                                )
                            }
                            Spacer(modifier = Modifier.padding(top = 13.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.btn_5),
                                    contentDescription = "Share",
                                    modifier = Modifier
                                        .height(45.dp)
                                        .width(45.dp)
                                )
                                Spacer(modifier = Modifier.padding(start = 20.dp))
                                Text(
                                    text = "Share",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.W500,
                                    color = Color.DarkGray,
                                    fontStyle = FontStyle.Normal
                                )
                            }
                            Spacer(modifier = Modifier.padding(top = 13.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){authViewModel.signout()},
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(R.drawable.btn_6),
                                    contentDescription = "button1",
                                    modifier = Modifier
                                        .height(45.dp)
                                        .width(45.dp)
                                )
                                Spacer(modifier = Modifier.padding(start = 20.dp))
                                Text(
                                    text = "Logout",
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.W500,
                                    color = Color.DarkGray,
                                    fontStyle = FontStyle.Normal
                                )
                            }
                        }

                    }
                }
            }
        }
    }
}