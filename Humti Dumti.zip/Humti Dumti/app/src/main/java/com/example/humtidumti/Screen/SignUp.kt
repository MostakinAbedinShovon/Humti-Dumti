package com.example.humtidumti.Screen

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.R
import com.example.humtidumti.ui.theme.signup_1
import com.example.humtidumti.ui.theme.signup_2
import com.example.humtidumti.ui.theme.signup_3

@Composable
fun SignUp(modifier: Modifier = Modifier, navController: NavController, authViewModel: AuthViewModel) {
    val authState = authViewModel.authState.observeAsState()
    val context = LocalContext.current

    LaunchedEffect(authState.value) {
        when (authState.value) {
            is AuthState.Authenticated -> navController.navigate("Login") {
                popUpTo(navController.graph.startDestinationId) { inclusive = true }
                launchSingleTop = true
            }
            is AuthState.Error -> Toast.makeText(context, (authState.value as AuthState.Error).message, Toast.LENGTH_SHORT).show()
            else -> Unit
        }
    }

    val isAuthenticated = authState.value is AuthState.Authenticated
    BackHandler(enabled = isAuthenticated) {
        (context as? Activity)?.finish()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(signup_3, signup_2, signup_1),
                    startY = 0f,
                    endY = Float.POSITIVE_INFINITY
                )
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 55.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Image(
                painter = painterResource(id = R.drawable.img_coder),
                contentDescription = "Coder_PNG",
                modifier = Modifier.size(200.dp)
            )

            Text(
                text = "Hey, there!",
                fontSize = 15.sp,
                color = Color.White,
            )

            Text(
                text = "Let's Get Started",
                fontSize = 25.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold,
            )

            Spacer(modifier = Modifier.height(15.dp))

            var name by remember { mutableStateOf("") }
            var email by remember { mutableStateOf("") }
            var password by rememberSaveable { mutableStateOf("") }
            var passvis1 by remember { mutableStateOf(false) }
            val icon1 = if (passvis1) painterResource(id = R.drawable.show_pass) else painterResource(id = R.drawable.hide_pass)

            // Name Input
            OutlinedTextField(
                modifier = Modifier
                    .height(60.dp)
                    .width(320.dp),
                value = name,
                singleLine = true,
                onValueChange = { newText -> name = newText },
                shape = RoundedCornerShape(24.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                placeholder = {
                    Text("Full Name", fontSize = 17.sp)
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Text,
                    imeAction = ImeAction.Next
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Email Input
            OutlinedTextField(
                modifier = Modifier
                    .height(60.dp)
                    .width(320.dp),
                value = email,
                singleLine = true,
                onValueChange = { newText -> email = newText },
                shape = RoundedCornerShape(24.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                placeholder = {
                    Text("Email", fontSize = 17.sp)
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Password Input
            OutlinedTextField(
                modifier = Modifier
                    .height(60.dp)
                    .width(320.dp),
                value = password,
                singleLine = true,
                onValueChange = { password = it },
                shape = RoundedCornerShape(24.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                placeholder = {
                    Text("Password", fontSize = 17.sp)
                },
                trailingIcon = {
                    IconButton(onClick = { passvis1 = !passvis1 }) {
                        Icon(
                            painter = icon1,
                            contentDescription = "Visibility Icon",
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                visualTransformation = if (passvis1) VisualTransformation.None else PasswordVisualTransformation()
            )
            Spacer(modifier = Modifier.height(25.dp))
            Button(
                modifier = Modifier
                    .height(54.dp)
                    .width(200.dp)
                    .shadow(elevation = 20.dp, shape = RoundedCornerShape(percent = 50)),
                onClick = {
                    authViewModel.signup(name ,email, password)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6650a4),
                    contentColor = Color.White
                )
            ) {
                Text(fontSize = 16.sp, text = "Sign Up")
            }
            TextButton(
                onClick = { navController.navigate("Login") {
                    popUpTo("Flash") { inclusive = true }
                    popUpTo("Login") { inclusive = true }
                } }
            ) {
                Text(text = "Already have an account? Log in", fontSize = 17.sp, color = Color.White)
            }
        }
    }
}

data class humdum(val name: String, val email: String, val role: String)
