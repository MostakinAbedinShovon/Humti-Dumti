package com.example.humtidumti.Screen

import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.R
import com.exyte.animatednavbar.AnimatedNavigationBar
import com.exyte.animatednavbar.animation.balltrajectory.Straight
import com.exyte.animatednavbar.utils.noRippleClickable

@Composable
fun Setting( modifier: Modifier = Modifier,
          navController: NavController,
          authViewModel: AuthViewModel){
    Box(
        modifier = Modifier
            .fillMaxSize(),
    ){
        val navigationBarItems = remember { NavigationBarItems.values() }
        var selectedIndex by remember { mutableStateOf(0) }

        Scaffold(
            modifier = Modifier.padding(bottom = 20.dp),
            bottomBar = {
                AnimatedNavigationBar(
                    modifier = Modifier
                        .height(57.dp)
                        .width(320.dp)
                        .padding(start = 45.dp)
                        .clip(RoundedCornerShape(40.dp)),
                    selectedIndex = 3,
                    ballAnimation = Straight(tween(800)),
                    barColor = Color(0xFFC21E56),
                    ballColor = Color(0xFFC21E56),
                ) {
                    navigationBarItems.forEach { item ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .noRippleClickable {
                                    selectedIndex = item.ordinal
                                    if(item.ordinal == 0) navController.navigate("Dashboard")
                                    else if(item.ordinal == 1) navController.navigate("Cart")
                                    else if(item.ordinal == 2) navController.navigate("Itemlist")
                                    else if(item.ordinal == 3) navController.navigate("Setting")
                                    else if(item.ordinal == 4) navController.navigate("Profile")
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                modifier = Modifier.size(27.dp),
                                imageVector = item.icon,
                                contentDescription = "Bottom Bar Icon",
                                tint = if (selectedIndex != item.ordinal)
                                    Color.White
                                else
                                    Color.LightGray
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .padding(innerPadding)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    myfunc()
                }
            }
        }
    }
}

@Preview
@Composable
fun myfunc(){
        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            Box(
                modifier = Modifier.fillMaxSize().background(Color.White)
            ) {}
            Card(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(bottom = 580.dp),
                shape = RoundedCornerShape(bottomEnd = 30.dp, bottomStart = 30.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFC21E56)
                )
            ) {
                Text(
                    text = "Setting",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.W500,
                    color = Color.White,
                    modifier = Modifier.padding(start = 130.dp, top = 25.dp),
                    fontStyle = FontStyle.Normal
                )
                Spacer(modifier = Modifier.padding(top = 10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 10.dp)
                ) {
                    var value by rememberSaveable { mutableStateOf("") }
                    OutlinedTextField(
                        modifier = Modifier
                            .height(52.dp)
                            .width(340.dp)
                            .shadow(
                                elevation = 20.dp,
                                shape = RoundedCornerShape(percent = 30)
                            ),
                        value = value,
                        singleLine = true,
                        onValueChange = { newText -> value = newText },
                        shape = RoundedCornerShape(10.dp),
                        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        ),
                        placeholder = {
                            Text(
                                "Search",
                                fontSize = 17.sp,
                            )
                        },
                        leadingIcon = {
                            IconButton(onClick = {}) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = "Search Icon"
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Text,
                            imeAction = ImeAction.Search
                        )
                    )
                }
            }
            LazyColumn(
                modifier = Modifier
                    .padding(start = 15.dp , end = 7.dp , top = 160.dp)
                    .height(620.dp)
            ) {
                item() {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(end = 15.dp)
                                .clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp))
                                .clickable{},
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.order),
                                contentDescription = "button1",
                                modifier = Modifier
                                    .height(48.dp)
                                    .width(48.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 20.dp))
                            Text(
                                text = "Order",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.W500,
                                color = Color.DarkGray,
                                fontStyle = FontStyle.Normal
                            )
                        }
                        Spacer(modifier = Modifier.padding(top = 13.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.payment),
                                contentDescription = "button1",
                                modifier = Modifier
                                    .height(48.dp)
                                    .width(48.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 20.dp))
                            Text(
                                text = "Payment",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.W500,
                                color = Color.DarkGray,
                                fontStyle = FontStyle.Normal
                            )
                        }
                        Divider(modifier = Modifier.padding(vertical = 10.dp , horizontal = 75.dp).width(200.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.pass),
                                contentDescription = "button1",
                                modifier = Modifier
                                    .height(48.dp)
                                    .width(48.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 20.dp))
                            Text(
                                text = "Password & Biometric",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.W500,
                                color = Color.DarkGray,
                                fontStyle = FontStyle.Normal
                            )
                        }
                    Spacer(modifier = Modifier.padding(top = 13.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(R.drawable.privacy),
                            contentDescription = "Share",
                            modifier = Modifier
                                .height(48.dp)
                                .width(48.dp)
                        )
                        Spacer(modifier = Modifier.padding(start = 20.dp))
                        Text(
                            text = "Privacy",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.W500,
                            color = Color.DarkGray,
                            fontStyle = FontStyle.Normal
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 10.dp , horizontal = 75.dp).width(200.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.support),
                                contentDescription = "button1",
                                modifier = Modifier
                                    .height(48.dp)
                                    .width(48.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 20.dp))
                            Text(
                                text = "Support",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.W500,
                                color = Color.DarkGray,
                                fontStyle = FontStyle.Normal
                            )
                        }
                    Spacer(modifier = Modifier.padding(top = 13.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(R.drawable.help),
                            contentDescription = "button1",
                            modifier = Modifier
                                .height(48.dp)
                                .width(48.dp)
                        )
                        Spacer(modifier = Modifier.padding(start = 20.dp))
                        Text(
                            text = "Help",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.W500,
                            color = Color.DarkGray,
                            fontStyle = FontStyle.Normal
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 10.dp , horizontal = 75.dp).width(200.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Image(
                                painter = painterResource(R.drawable.about),
                                contentDescription = "button1",
                                modifier = Modifier
                                    .height(48.dp)
                                    .width(48.dp)
                            )
                            Spacer(modifier = Modifier.padding(start = 20.dp))
                            Text(
                                text = "About",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.W500,
                                color = Color.DarkGray,
                                fontStyle = FontStyle.Normal
                            )
                        }
                    Spacer(modifier = Modifier.padding(top = 13.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(end = 15.dp).clip(RoundedCornerShape(topStart = 20.dp , topEnd = 20.dp ,bottomEnd = 20.dp, bottomStart = 20.dp)).clickable(){},
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(R.drawable.faq),
                            contentDescription = "button1",
                            modifier = Modifier
                                .height(48.dp)
                                .width(48.dp)
                        )
                        Spacer(modifier = Modifier.padding(start = 20.dp))
                        Text(
                            text = "FAQ",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.W500,
                            color = Color.DarkGray,
                            fontStyle = FontStyle.Normal
                        )
                    }
                }
            }
        }
    }