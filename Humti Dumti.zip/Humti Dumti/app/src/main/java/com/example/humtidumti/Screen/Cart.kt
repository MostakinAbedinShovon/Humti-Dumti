package com.example.humtidumti.Screen

import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.humtidumti.CartItem
import com.example.humtidumti.CartViewModel
import com.example.humtidumti.R
import com.exyte.animatednavbar.AnimatedNavigationBar
import com.exyte.animatednavbar.animation.balltrajectory.Straight
import com.exyte.animatednavbar.utils.noRippleClickable

@Composable
fun Cart(
    modifier: Modifier = Modifier,
    navController: NavController,
    authViewModel: AuthViewModel,
    cartViewModel: CartViewModel
) {
    val cartItems = cartViewModel.cartItems
    val totalPrice = cartViewModel.totalPrice
    val isCartEmpty = cartViewModel.isCartEmpty
    val navigationBarItems = remember { NavigationBarItems.values() }
    var selectedIndex by remember { mutableStateOf(0) }


    Scaffold(
        modifier = Modifier.padding(bottom = 20.dp),
        bottomBar = {
            AnimatedNavigationBar(
                modifier = Modifier
                    .height(57.dp)
                    .width(320.dp)
                    .padding(start = 45.dp)
                    .clip(RoundedCornerShape(40.dp)),
                selectedIndex = 1,
                ballAnimation = Straight(tween(800)),
                barColor = Color(0xFFC21E56),
                ballColor = Color(0xFFC21E56),
            ) {
                navigationBarItems.forEach { item ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .noRippleClickable {
                                selectedIndex = item.ordinal
                                if(item.ordinal == 0) navController.navigate("Dashboard")
                                else if(item.ordinal == 1) navController.navigate("Cart")
                                else if(item.ordinal == 2) navController.navigate("Itemlist")
                                else if(item.ordinal == 3) navController.navigate("Setting")
                                else if(item.ordinal == 4) navController.navigate("Profile")
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            modifier = Modifier.size(27.dp),
                            imageVector = item.icon,
                            contentDescription = "Bottom Bar Icon",
                            tint = if (selectedIndex != item.ordinal)
                                Color.White
                            else
                                Color.LightGray
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
            ){
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.White)
                ){}
                Card(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(bottom = 650.dp),
                    shape = RoundedCornerShape(bottomEnd = 30.dp, bottomStart = 30.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFC21E56)
                    )
                ) {
                    Text(
                        text = "Cart",
                        fontSize = 30.sp,
                        fontWeight = FontWeight.W500,
                        color = Color.White,
                        modifier = Modifier.padding(start = 150.dp, top = 25.dp),
                        fontStyle = FontStyle.Normal
                    )
                }
                if (isCartEmpty) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "Cart Is Empty",
                            color = Color.DarkGray,
                            fontSize = 40.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontStyle = FontStyle.Italic
                        )
                    }
            }
                else {

                    LazyColumn(
                        modifier = Modifier
                            .padding(top = 85.dp, start = 10.dp, end = 7.dp, bottom = 120.dp)
                            .height(620.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        items(cartItems) { cartItem ->

                            Card(
                                modifier = Modifier
                                    .padding(vertical = 5.dp)
                                    .shadow(
                                        shape = RoundedCornerShape(
                                            bottomStart = 15.dp,
                                            bottomEnd = 15.dp,
                                            topStart = 25.dp,
                                            topEnd = 25.dp
                                        ),
                                        elevation = 8.dp,
                                    ),
                                colors = CardDefaults.cardColors(
                                    containerColor = Color.White
                                ),
                            ) {
                                CartItemRow(cartItem, cartViewModel)
                            }
                        }
                    }
                Spacer(modifier = Modifier.padding(top = 10.dp))
                Column(
                    modifier = Modifier
                        .padding(top = 610.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Total Price:",
                            fontWeight = FontWeight.SemiBold,
                            color = Color.DarkGray,
                            fontSize = 17.sp
                        )
                        Text(
                            text = "${totalPrice}/-",
                            color = Color.DarkGray,
                            fontSize = 14.sp,
                            modifier = Modifier.padding(start = 10.dp)
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 5.dp))
                    val context = LocalContext.current
                    Button(
                        modifier = Modifier
                            .padding(10.dp)
                            .height(54.dp)
                            .width(150.dp)
                            .shadow(
                                elevation = 10.dp,
                                shape = RoundedCornerShape(percent = 50)
                            ),
                        onClick = {},
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC21E56),
                            contentColor = Color.White
                        )
                    ) {
                        Text(
                            fontSize = 16.sp,
                            text = "Place Order"
                        )
                    }
                }
                }
            }
        }
    }
}
@Composable
fun CartItemRow(cartItem: CartItem, cartViewModel: CartViewModel) {
    Row(
        modifier = Modifier
            .fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = cartItem.image,
            contentDescription = cartItem.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .height(90.dp)
                .width(110.dp)
                .padding(end = 10.dp)
                .shadow(
                    shape = RoundedCornerShape(bottomStart = 15.dp, bottomEnd = 15.dp , topStart = 15.dp , topEnd = 15.dp),
                    elevation = 5.dp,
                )

        )
        Column(modifier = Modifier.weight(1f)) {
            Text(text = cartItem.title, fontWeight = FontWeight.SemiBold, color = Color.DarkGray , fontSize = 17.sp, modifier = Modifier.padding(top = 5.dp))
            Text(text = "${cartItem.count}x${cartItem.price}/-", color = Color(0xFF71797E) , fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
            Text(text = "${cartItem.count*cartItem.price}/-", color = Color(0xFFE30B5C), fontSize = 16.sp, modifier = Modifier.padding(top = 5.dp))
        }

        Row(modifier = Modifier
            .padding(end = 7.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(R.drawable.decrease),
                contentDescription = "Profile Pic",
                modifier = Modifier
                    .height(25.dp)
                    .width(25.dp)
                    .clickable(onClick = { cartViewModel.decreaseItemCount(cartItem) })
            )
            Text(text = "${cartItem.count}", modifier = Modifier.padding(horizontal = 10.dp))

            Image(
                painter = painterResource(R.drawable.increase),
                contentDescription = "Profile Pic",
                modifier = Modifier
                    .height(25.dp)
                    .width(25.dp)
                    .clickable(onClick = {
                        cartViewModel.increaseItemCount(cartItem)
                    }
                )
            )
        }
    }
}