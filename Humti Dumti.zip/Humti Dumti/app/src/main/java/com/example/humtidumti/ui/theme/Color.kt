package com.example.humtidumti.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val flash_button1 = Color(0xff24FE41)
val flash_button2 = Color(0xffFDFC47)


val home_back_1 = Color(0xff164863)
val home_back_2 = Color(0xff427d9d)
val home_back_3 = Color(0xff9bbec8)


val signup_1 = Color(0xff8675a9)
val signup_2 = Color(0xffc3aed6)
val signup_3 = Color(0xffefbbcf)