package com.example.humtidumti

import androidx.compose.ui.graphics.painter.Painter

data class CartItem(
    val id: String,
    val price: Int,
    val title: String,
    var count: Int,
    val image: Painter,
    val time: String
)
